const jwt = require('jsonwebtoken');
const User = require('../models/user'); // Убедитесь, что путь к модели корректен

module.exports = async (req, res, next) => {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
        return res.status(401).json({ message: 'No token provided' });
    }

    try {
        // Расшифровка токена
        const decoded = jwt.verify(token, process.env.SECRET_KEY);

        // Поиск пользователя в базе данных
        const user = await User.findById(decoded.id).select('-password'); // Убираем пароль из результата

        if (!user) {
            return res.status(401).json({ message: 'Invalid token' });
        }

        // Добавляем данные пользователя в запрос
        req.user = user;

        // Передаём управление следующему middleware
        next();
    } catch (err) {
        // Если токен недействителен
        return res.status(401).json({ message: 'Invalid token' });
    }
};
